package in.ineuron.dao;

public interface InsurancePolicyDao {
	public String transferPremiumPolicies(int maxTenure);
}
